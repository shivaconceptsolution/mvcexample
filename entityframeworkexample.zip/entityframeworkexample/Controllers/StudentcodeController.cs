﻿using entityframeworkexample.Models.DB;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
namespace entityframeworkexample.Controllers
{
    public class StudentcodeController : Controller
    {
        private CollegeerpContext db;
        public StudentcodeController(CollegeerpContext db)
        {
            this.db = db;
        }
        public IActionResult Index()
        {
            var s = db.Students.ToList();  // select * from students
            return View(s);
        }
        public IActionResult EditStudent(int? id)
        {
            var s = db.Students.Find(id);  // select * from students
            return View(s);
        }
        [HttpPost]
        public IActionResult EditStudent(Student obj)
        {
            db.Entry(obj).State = EntityState.Modified;
            db.SaveChanges();
            return RedirectToAction("Index");
        }
        public IActionResult DeleteStudent(int? id)
        {
            var s = db.Students.Find(id);  // select * from students
            return View(s);
        }
        [HttpPost]
        public IActionResult DeleteStudent(Student obj)
        {
            db.Students.Remove(obj);
            db.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}
