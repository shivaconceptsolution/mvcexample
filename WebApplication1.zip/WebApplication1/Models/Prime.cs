﻿namespace WebApplication1.Models
{
    public class Prime
    {
        private int num;

        public int Num { get => num; set => num = value; }
    }
}
