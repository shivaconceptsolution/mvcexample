﻿namespace WebApplication1.Models
{
    public class SI
    {
        private float _p;
        private float __r;
        private float _t;

        public float P { get => _p; set => _p = value; }
        public float R { get => __r; set => __r = value; }
        public float T { get => _t; set => _t = value; }
    }
}
