﻿namespace WebApplication1.Models
{
    public class Swap
    {
        private int a;
        private int b;

        public int A { get => a; set => a = value; }
        public int B { get => b; set => b = value; }
    }
}
