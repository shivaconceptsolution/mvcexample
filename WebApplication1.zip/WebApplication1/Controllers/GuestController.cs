﻿using Microsoft.AspNetCore.Mvc;

namespace WebApplication1.Controllers
{
    public class GuestController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Aboutus()
        {
            return View();
        }
        public IActionResult Services()
        {
            return View();
        }
        public IActionResult Contactus()
        {
            return View();
        }
        public IActionResult Gallery()
        {
            return View();
        }
    }
}
