﻿using Microsoft.AspNetCore.Mvc;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class PrimeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Index(Prime o)
        {
            int num = o.Num;
            String s = "prime";
            for(int i=2;i<num;i++)
            {
                if(num%i==0)
                {
                    s = "not prime";
                    break;
                }
            }
            ViewBag.data = s;
            return View();
        }

    }
}
