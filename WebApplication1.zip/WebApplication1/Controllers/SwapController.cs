﻿using Microsoft.AspNetCore.Mvc;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class SwapController : Controller
    {
        
        public IActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Index(Swap o)
        {
            int num1 = o.A;
            o.A = o.B;
            o.B=num1;
            ViewBag.Data = "a=" + o.A + "b=" + o.B;
            return View();
        }

    }
}
