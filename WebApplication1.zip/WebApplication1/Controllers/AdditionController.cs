﻿using Microsoft.AspNetCore.Mvc;

namespace WebApplication1.Controllers
{
    public class AdditionController:Controller
    {
        [HttpGet]
        public ActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Index(IFormCollection obj)
        {
            int a = Convert.ToInt32(obj["txtnum1"].ToString());
            int b = Convert.ToInt32(obj["txtnum2"].ToString());
            int c = a+ b;
            ViewBag.data = "Result is " + c;
            return View();
        }
    }
}
