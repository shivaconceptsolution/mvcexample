﻿using Microsoft.AspNetCore.Mvc;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class SIController : Controller
    {
        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Index(SI obj)
        {
            float result = (obj.P * obj.R * obj.T) / 100;
            ViewBag.data = "Result is " + result;
            return View();
        }

    }
}
